 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
 <htmlxmlns="http://www.w3.org/1999/xhtml">
 <head>
 <metahttp-equiv="Content-Type"content="text/html; charset=iso-8859-1"/>
 <title>Daftar Supplier</title>
 <linkhref="<?php echo base_url();?>style/style.css"
 rel="stylesheet"type="text/css"/>
 </head>
 <body>
 <div class="content">
 <h1>Daftar Master Customer</h1>
 <div class="paging"><?php echo $pagination;?></div>
 <div class="data"><?php echo $table;?></div>
 <div class="paging"><?php echo $pagination;?></div><br/>
 
 </div>
</body>
</html>