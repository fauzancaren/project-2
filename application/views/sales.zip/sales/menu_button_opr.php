<?php 
			
            add_button_menu("Sales Order","sales_order",
            "ico_rekening.png","Pembuatan order penjualan (SO)");
            add_button_menu("Delivery Order","delivery_order",
            "ico_rekening.png","Pembuatan surat jalan /Delivery Order / DO");
            add_button_menu("Faktur Penjualan","invoice",
            "ico_rekening.png","Invoice pencatatan piutang pelanggan");
            add_button_menu("Bayar Piutang","payment",
            "ico_rekening.png","Proses pembayaran piutang atas faktur pelanggan");
            add_button_menu("Retur Penjualan","sales_retur",
            "ico_rekening.png","Pengembalian barang dari pelanggan");
            add_button_menu("Debit Memo","sales_dbmemo",
            "ico_rekening.png","Debit memo");
            add_button_menu("Credit Memo","sales_crmemo",
            "ico_rekening.png","Credit memo");
            add_button_menu("Kontra bon","so/kontra_bon",
            "ico_rekening.png","Rencana penerimaan pembayaran piutang faktur pelanggan");
            add_button_menu("Tagihan Kolektor","so/bill_collect",
            "ico_rekening.png","Pembuatan tagihan kolektor");
            add_button_menu("Promosi Discount","so/promosi_disc",
            "ico_rekening.png","Promosi discount barang penjualan");
            add_button_menu("Promosi Extra Qty","so/promosi_extra",
            "ico_rekening.png","Promosi extra quantity (ex: beli 2 gratis 1");
            add_button_menu("Promosi Poin Reward","so/promosi_point",
            "ico_rekening.png","Seting poin reward");
            add_button_menu("Promosi Voucher","so/promosi_voucher",
            "ico_rekening.png","Seting promosi voucher belanja");
            add_button_menu("Master Pelanggan","customer",
            "ico_rekening.png","Daftar master pelanggan /customer");
            add_button_menu("Master Salesman","salesman",
            "ico_rekening.png","Daftar master salesman");
            add_button_menu("Master Termin","type_of_payment",
            "ico_rekening.png","Daftar master termin");
            
?>