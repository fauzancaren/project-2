<a href="#mnSales" data-toggle="collapse">
<span style='float:left;width:30px;margin-left:5px'><img src="<?=base_url("images/success.gif")?>"></i></span>
    <p style="color:yellow" ><b>Sales Order Modules</p></p>
</a>
<div id="mnSales" class="collapse">
<li><?=anchor(base_url().'index.php/sales_order','Daftar Sales Order','class=""  ');?></li>
<li><?=anchor(base_url().'index.php/delivery_order','Daftar Delivery Order (DO)','class=""  ');?></li>
<li><?=anchor(base_url().'index.php/invoice','Daftar Sales Invoice','class=""  ');?></li>
<li><?=anchor(base_url().'index.php/so/kontra_bon','Daftar Kontra Bon','class=""  ');?></li>
<li><?=anchor(base_url().'index.php/so/bill_collect','Tagihan Kolektor','class=""  ');?></li>
<li><?=anchor(base_url().'index.php/sales_crmemo','Kredit Memo','class=""');?></li>
<li><?=anchor(base_url().'index.php/sales_dbmemo','Debit Memo','class=""');?></li>
<li><?=anchor(base_url().'index.php/payment','Daftar Pembayaran Invoice','class=""  ');?></li>
<li><?=anchor(base_url().'index.php/sales_retur','Daftar Sales Return','class=""  ');?></li>
<li><?=anchor(base_url().'index.php/retur_toko','Retur barang dari toko','class=""');?></li>
<li><?=anchor(base_url().'index.php/so/promosi_disc','Promosi Discount Penjualan','class=""  ');?></li>
<li><?=anchor(base_url().'index.php/so/promosi_extra','Promosi Quantity Extra','class=""  ');?></li>
<li><?=anchor(base_url().'index.php/so/promosi_point','Promosi Point Reward','class=""  ');?></li>
<li><?=anchor(base_url().'index.php/so/promosi_voucher','Promosi Voucher','class=""  ');?></li>
<li><?=anchor(base_url().'index.php/so/service','Service Order','class=""  ');?></li>
<li><?=anchor(base_url().'index.php/customer','Pelanggan','class=""');?></li>
<li><?=anchor(base_url().'index.php/salesman','Salesman','class=""');?></li>
<li><?=anchor(base_url().'index.php/type_of_payment','Termin','class=""');?></li>
<li><?=anchor(base_url().'index.php/company/wilayah',"Wilayah","class=''");?></li>
<li><?=anchor(base_url().'index.php/customer_type','Customer Type','class=""');?></li>
</div>