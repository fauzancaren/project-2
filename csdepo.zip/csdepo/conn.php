<?php 
$koneksi = mysqli_connect("127.0.0.1","root","atl24nta","maxon4");
?>
